 function banner () {
    return ( 
              <h1 className="bannerh1">AKSHIT CHADHA BLOG </h1>   
    );
}
 
export default banner ;