function NavBar ()  {
    return (  
        <nav className="main-nav">
  <ul className="nav-ul">
   <li className ="nav-li"><a  className="nav-anchortag" href="/" >Home</a></li>
   <li className ="nav-li"><a className="nav-anchortag"  href="/create.html" >Create</a></li>
  </ul>
</nav>
    );
}
 
export default NavBar ;