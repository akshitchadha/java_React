import Banner from './banner';
import NavBar from './navbar';
import Home from './Home';



function App() {

  
  return (
    <div className="App">
      <Banner/>
    <NavBar/>
      <div className="content">
        <Home/>
        
      </div>
      </div>
  );
}

export default App;
