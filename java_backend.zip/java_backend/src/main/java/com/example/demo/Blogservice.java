package com.example.demo;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class Blogservice {



    public List<Blog> getBlogs() {

        List<Blog> blogs=new ArrayList<>();

        for (int i=0;i<=DemoApplication.blogs.size();i++)
        {

            if(DemoApplication.blogs.get(i)!= null)
            {
                blogs.add(DemoApplication.blogs.get(i));
        }}
        return blogs;
    }


}
