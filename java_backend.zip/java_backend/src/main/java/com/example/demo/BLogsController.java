package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class BLogsController {
    @Autowired
    Blogservice blogservice;

     @GetMapping("blogs")
    public List<Blog> getBlog()
    {
        return  blogservice.getBlogs();
    }


}
