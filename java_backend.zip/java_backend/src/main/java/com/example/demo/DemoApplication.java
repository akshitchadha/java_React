package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.HashMap;
import java.util.Map;

@SpringBootApplication
public class DemoApplication {
	static Map<Integer,Blog> blogs=new HashMap<>();

	static{

		blogs.put(0,new Blog("My First Blog","hello world"
		,"mario",0));

		blogs.put(1,new Blog("My SECOND Blog","hello world2"
				,"SAM",1));

		blogs.put(2,new Blog("My THIRD Blog","hello world3"
				,"SAM",2));
		blogs.put(3,new Blog("My FOUR Blog","hello world4"
				,"RAJESH",3));

	}
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

}
