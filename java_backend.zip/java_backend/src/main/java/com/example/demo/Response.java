package com.example.demo;

import java.util.HashMap;
import java.util.Map;

public class Response {

   String result;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
